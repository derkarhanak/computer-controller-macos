#!/bin/bash

echo "🚀 Launching Computer Controller..."
open "Computer Controller.app"
echo "✅ App launched! Check your dock or Applications folder."
